﻿namespace Salesforce.Common.Models
{
    public enum DisplayTypes
    {
        Page,
        Popup,
        Touch,
        Mobile
    }
}