﻿namespace Salesforce.Common.Models
{
    public enum ResponseTypes
    {
        Code,
        Token
    }
}