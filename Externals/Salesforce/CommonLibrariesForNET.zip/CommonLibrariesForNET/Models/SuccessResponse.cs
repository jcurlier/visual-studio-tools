﻿namespace Salesforce.Common.Models
{
    public class SuccessResponse
    {
        public string id;
        public string success;
        public object errors;
    }
}

