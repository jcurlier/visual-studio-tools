﻿namespace Salesforce.Common.Models
{
    public class ErrorResponse
    {
        public string message;
        public string errorCode;
    }
}
