﻿using System.Collections.Generic;

namespace Salesforce.Common.Models
{
    public class ErrorResponses : List<ErrorResponse> { }
}
