﻿namespace Salesforce.Common.Models
{
    public class AuthErrorResponse
    {
        public string error_description;
        public string error;
    }
}